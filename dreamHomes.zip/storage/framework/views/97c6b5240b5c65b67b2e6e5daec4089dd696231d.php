<?php
  use App\Http\Controllers\DocumentsController;
?>

  <?php $__currentLoopData = $member->document->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/admin/files/download/<?php echo e($document->id); ?>">
      <span class="doc-li text-primary"><?php echo e(DocumentsController::readableName($document)); ?></span>
    </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/components/documents_popup.blade.php ENDPATH**/ ?>