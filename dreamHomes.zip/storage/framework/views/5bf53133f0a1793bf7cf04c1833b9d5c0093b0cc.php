
<div class="office-filter" id="office-filter<?php echo e($member->id); ?>">
<div></div>
<div class="office-card" id="member-details<?php echo e($member->id); ?>">
  <div class="mem-top-nav bg-primary">
    <p class="pop-topBar">Office Use</p>
    <i class="fas fa-times" onclick="toggleOfficePopup(<?php echo e($member->id); ?>)"></i>
    <i class="fas fa-save" onclick="saveMember(<?php echo e($member->id); ?>)"></i>
    
    <span class="msg-line" id="msg-line<?php echo e($member->id); ?>"></span>
  </div>

  <form class="form-50" id="member-form<?php echo e($member->id); ?>" action="/updateMember" method="POST">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="id" value="<?php echo e($member->id); ?>">

    <div class="dash-form-group">
      <label for="created_at">Date of Application: </label>
      <input class="borderless" type="text" name="miscs[created_at]" value="<?php echo e($member->misc->created_at); ?>" readonly>
    </div>
 
    <div class="dash-form-group">
      <label for="membership_no">Membership Number: </label>
      <input class="borderless" type="text" name="miscs[membership_no]" value="<?php echo e($member->misc->membership_no); ?>">
    </div>
    
    <div class="dash-form-group">
      <label for="member_certified_id">Status</label>
      <select name="miscs[status]">
        <?php
          $mStatus = $member->misc->status;
          use App\Http\Controllers\MemberController;
          $allStatus = MemberController::status();
        ?>
        <?php $__currentLoopData = $allStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($status); ?>" <?php if($status == $mStatus): ?> selected <?php endif; ?>><?php echo e($status); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="member_certified_id">ID Document</label>
      <select name="miscs[member_certified_id]">
        <?php $mID = $member->misc->member_certified_id ?>
        <option value='Not Received' <?php if($mID == 'Not Received'): ?> selected <?php endif; ?>>Not Received</option>
        <option value='Received' <?php if($mID == 'Received'): ?> selected <?php endif; ?>>Received</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="join_fee">Joining Fee: </label>
      <?php $jFee= $member->misc->join_fee ?>
      <select name='miscs[join_fee]'>
        <option value='Not Received' <?php if( $jFee=='Not Received'): ?> selected <?php endif; ?>>Not Received</option>
        <option value='Received' <?php if( $jFee=='Received'): ?> selected <?php endif; ?>>Received</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="position">Position: </label>
      <input class="borderless" type="number" name="miscs[position]" value="<?php echo e($member->misc->position); ?>">
    </div>

    <div class="dash-form-group">
      <label for="pop">Proof of Payment: </label>
      <?php $pop= $member->misc->pop ?>
      <select name='miscs[pop]'>
        <option value='Not Received' <?php if( $pop=='Not Received'): ?> selected <?php endif; ?>>Not Received</option>
        <option value='Received' <?php if( $pop=='Received'): ?> selected <?php endif; ?>>Received</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="date_payment">Date of<br>Payment: </label>
      <input class="borderless" type="date" name="miscs[date_payment]" value="<?php echo e($member->misc->date_payment); ?>">
    </div>

    <div class="dash-form-group">
      <label for="nok">Spouse/Next Of Kin: </label>
      <?php $nok= $member->misc->nok ?>
      <select name='miscs[nok]'>
        <option value='Not Confirmed' <?php if( $nok=='Not Confirmed'): ?> selected <?php endif; ?>>Not Confirmed</option>
        <option value='Confirmed' <?php if( $nok=='Confirmed'): ?> selected <?php endif; ?>>Confirmed</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="nok_id">Spouse/Next Of Kin ID: </label>
      <?php $nokID= $member->misc->nok_id ?>
      <select name='miscs[nok_id]'>
        <option value='Not Received' <?php if( $nokID=='Not Received'): ?> selected <?php endif; ?>>Not Received</option>
        <option value='Received' <?php if( $nokID=='Received'): ?> selected <?php endif; ?>>Received</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="beneficiary">Beneficiaries: </label>
      <?php $benf= $member->misc->beneficiary ?>
      <select name='miscs[beneficiary]'>
        <option value='Not Confirmed' <?php if( $benf=='Not Confirmed'): ?> selected <?php endif; ?>>Not Confirmed</option>
        <option value='Confirmed' <?php if( $benf=='Confirmed'): ?> selected <?php endif; ?>>Confirmed</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="beneficiary_id">Beneficiaries IDs: </label>
      <?php $benID= $member->misc->beneficiary_id ?>
      <select name='miscs[beneficiary_id]'>
        <option value='Not Received' <?php if( $benID=='Not Received'): ?> selected <?php endif; ?>>Not Received</option>
        <option value='Received' <?php if( $benID=='Received'): ?> selected <?php endif; ?>>Received</option>
      </select>
    </div>

    <div class="dash-form-group">
      <label for="updated_at">Date Updated: </label>
      <input class="borderless" type="text" name="miscs[updated_at]" value="<?php echo e($member->misc->updated_at); ?>" readonly>
    </div>

    <div class="dash-form-group">
      <label for="life_cover">Life Cover: </label>
      <input class="borderless" type="text" name="miscs[life_cover]" value="<?php echo e($member->misc->life_cover); ?>">
    </div>

    <div class="dash-form-group">
      <label for="processed_by">Updated By: </label>
      <?php
        $pById = $member->misc->processed_by;
        $pByName = ($pById == null) ? '': $processedBy[$pById]['name'].' '.$processedBy[$pById]['surname'];
      ?>
      <input class="borderless" type="text" name="miscs[processed_by]" value="<?php echo e($pByName); ?>" readonly>
    </div>
  </form>
</div>
<div></div>
</div><?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/components/office_use.blade.php ENDPATH**/ ?>