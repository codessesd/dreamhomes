<!DOCTYPE html>
<html>
<head>
  <title>Dream Homes Stokvel</title>
  <meta charset="utf-8">
  <meta name="description" content="Dream Homes Stokvel. A a unique housing stokvel enabling people to buy houses without the burden of interest rates">
  <meta name="keywords" content="dream homes, dreamhomes, dream homes stokvel, dreahomesstokvel, dream, homes, stokvel, home">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="/css/styles.css">
  <link rel="stylesheet" type="text/css" href="/css/applicationform.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Raleway&display=swap" rel="stylesheet">
</head>
<body>
  <div class="website">
    <div class="info-bar"></div>

    <div class="mobile-menu" id="menu-nav">
      
      <div class="filter-mob-menu"></div>
      <div class="mobile-logo">
        
      </div>
      <div class="mbl-menu">
        <ul>
            <li class="<?php echo $__env->yieldContent('home'); ?>"><a href="/"><img src="/images/m-home.svg"><br>Home</a></li>
            <li class="<?php echo $__env->yieldContent('about'); ?>"><a href="/about"><img src="/images/m-about.svg"><br>About</a></li>
            <li class="<?php echo $__env->yieldContent('contact'); ?>"><a href="/contact"><img src="/images/m-contact.svg"><br>Contact</a></li>
            <?php if(auth()->check()): ?>
              <li class="<?php echo $__env->yieldContent('profile'); ?>"><a href="/profile"><img src="/images/m-profile.svg"><br>Profile</a></li>
              <li><a href="/logout"><img src="/images/m-logout.svg"><br>Logout</a></li>
            <?php else: ?>
              <li class="<?php echo $__env->yieldContent('register'); ?>"><a href="/register"><img src="/images/m-register.svg"><br>Register</a></li> 
              <li><a href="/login"><img src="/images/m-login.svg"><br>Login</a></li>
            <?php endif; ?>
          </ul>
      </div>
     
    </div>


    <div class="header-container">
      <div class="logo">
        <a href="/"><img src="/images/logo.png" alt="dream homes stokvel"></a>
      </div>

      
      <div class="menu-btns-container">
        <div class="btn-open mbl-menu-btn"><img src="/images/menu.png"></div>
        <div class="btn-close mbl-menu-btn"><img src="/images/cross.png"></div>
      </div>
      <div class="menu-container main-menu">

      
          <ul>
            <li class="<?php echo $__env->yieldContent('home'); ?>"><a href="/">Home</a></li>
            <li class="<?php echo $__env->yieldContent('about'); ?>"><a href="/about">About</a></li>
            <li class="<?php echo $__env->yieldContent('contact'); ?>"><a href="/contact">Contact</a></li>
            <?php if(auth()->check()): ?>
              <li class="<?php echo $__env->yieldContent('profile'); ?>"><a href="/profile">Profile</a></li>
            <?php else: ?>
              <li class="<?php echo $__env->yieldContent('register'); ?>"><a href="/register">Register</a></li> 
            <?php endif; ?>
          </ul>
        <?php if(auth()->check()): ?>
          <span class="btn login"><a href="/logout">Logout</a></span>
        <?php else: ?>
          <span class="btn login"><a href="/login">Login</a></span>
        <?php endif; ?>
      </div>
    </div>

    <?php echo $__env->yieldContent('banner'); ?>

    <div class="fixed-div">
      <?php echo $__env->yieldContent('fixed-div'); ?>
    </div>
    <div class="section">
      <?php echo $__env->yieldContent('section'); ?>
    </div>

    <div class="wide-section1">
      <?php echo $__env->yieldContent('wide-section1'); ?>
      <div class="clr"></div>
    </div>

    <div class="footer">
      <div class="footer-inner">
        <div class="ftr-left"></div>
        <div class="ftr-mid">&copy;2020 Copyright DreamHomes Stokvel</div>
        <div class="ftr-right"></div>
      </div>
    </div>
  </div>


  <script type="text/javascript" src="/js/jquery.min.js"></script> 
  <script type="text/javascript" src="/js/script.js"></script>
  <script type="text/javascript" src="/js/mobile-menu.js"></script>
  <script src="https://kit.fontawesome.com/a5eb13ec56.js" crossorigin="anonymous"></script>
  <?php echo $__env->yieldContent('javascript'); ?>
</body>
</html><?php /**PATH C:\Laravel\dreamHomes\resources\views/layouts/master.blade.php ENDPATH**/ ?>