<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Members</h4>
            <p class="card-category">DHS member list</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                  </th>
                  <th>
                    Name
                  </th>
                  <th>
                    Membership
                  </th>
                  <th>
                    ID/Passport
                  </th>
                  <th>
                    Contact
                  </th>
                  <th>
                    Pos
                  </th>
                  <th class="text-center">
                    
                  </th>
                </thead>
                <tbody>
                  <?php $i = 0;/*members counter*/ ?>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <?php echo e(++$i); ?>

                      </td>
                      <td>
                        <?php echo e($member->f_name); ?> <?php echo e($member->surname); ?>

                      </td>
                      <td>
                        <?php echo e($member->membership_no); ?>

                      </td>
                      <td>
                        <?php echo e($member->id_passport_no); ?>

                      </td>
                      <td>
                        <?php echo e($member->cell_number); ?>

                      </td>
                      <td>
                        <?php echo e($member->position); ?>

                      </td>
                      <td class="status-td">
                        <div class="doc-popup-cover" id="<?php echo e($member['id']); ?>">
                          <?php echo $__env->make('components.documents_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="statuses d-flex justify-content-center">
                          <div class="edit" data-toggle="tooltip" data-placement="top" title="Edit Member">
                            <img src="/material/img/pen.svg">
                          </div>
                          <div class="status-inco" data-toggle="tooltip" data-placement="top" title="Application Incomplete">
                            <img src="/material/img/circle.svg">
                          </div>
                          
                          <div class="status-compl" onclick="showDocPopup(<?php echo e($member['id']); ?>)" data-toggle="tooltip" data-placement="top" title="Documents">
                            <img src="/material/img/documents.svg">
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'members', 'titlePage' => __('Members')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/pages/members.blade.php ENDPATH**/ ?>