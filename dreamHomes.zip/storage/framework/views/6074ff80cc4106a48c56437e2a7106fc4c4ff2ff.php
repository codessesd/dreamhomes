<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="/dashboard/dashboard.css">
  <link rel="stylesheet" type="text/css" href="/css/applicationform.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300&display=swap" rel="stylesheet">
</head>
<body>
<div class="dashboard">

  <div class="sidebar">
    <span class="dash-title">Dashboard</span>
    <ul class="side-nav-links">
      <li><a href="/members"><span class="side-icon">MB</span>Members</a></li>
      
      
      <li><a href="/admins"><span class="side-icon">AD</span>Admins</a></li>
      
    </ul>
  </div>
  <div class="mbl-menu bg-primary" id="mnBtn" onclick="mblMenuToggle()"><i id="mnIcn" class="icn fas fa-caret-down"></i></div>
  <div class="mbl-ddown bg-primary" id="mnDropdown">
    <ul class="side-nav-links">
      <li><a href="/members"><span class="side-icon">MB</span>Members</a></li>
      
      
      <li><a href="/admins"><span class="side-icon">AD</span>Admins</a></li>
      
    </ul>
  </div>

  <div class="content-wrap">
    <div class="top-nav">
      <div class="search">
      </div>
      <div class="user-menu">
        <div class="user-btn dd-btn bg-primary .bg-prm-hover">
          <i class="top-nav-icon fas fa-user"></i> 
          <ul class="dropdown-links user-links">
            <li>Change Password</li>
            <li><a href="/logout">Logout</a></li>
          </ul>
        </div>
        
      </div>
    </div>
    <div class="content">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </div>
</div>
<script type="text/javascript" src="/js/jquery.min.js"></script>
<script type="text/javascript" src="/dashboard/dashboard.js"></script>
<script src="https://kit.fontawesome.com/a5eb13ec56.js" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/layout/dashboard.blade.php ENDPATH**/ ?>