<?php $__env->startSection('profile','active'); ?>
<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('fixed-div'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php echo $__env->make('partials.fileUploader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(count($errors) > 0): ?>
    <?php echo $__env->make('partials.floatingMsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  

  <?php
    #NB! I must create a controller for this page and handle all the code in the controller!
    // get all member documents and store their ID and "readable" type in an array to list them later
    $member = auth()->user()->member;
    $docIDandType = [];
    $allDocuments = $member->document->all();

    foreach($allDocuments as $document){
      switch ($document->type) {
        case 'application':
          array_push($docIDandType, ['type'=>'Application Form','id'=>$document->id]);
          break;
        case 'idpassport':
          array_push($docIDandType, ['type'=>'ID or Passport','id'=>$document->id]);
          break;
        case 'proofop':
          array_push($docIDandType, ['type'=>'Proof Of Payment','id'=>$document->id]);
          break;
        case 'supportingdoc':
          array_push($docIDandType, ['type'=>'Supporting Document','id'=>$document->id]);
          break;
        default:
          array_push($docIDandType, ['type'=>'Invalid Format','id'=>$document->id]);
          break;
      }
    }
  ?>



  <h1 class="center-h"><span class="deBold">Your </span>Profile</h1>
  <div class="profile-div">
    <div class="profile-btns-mobile">
      <?php echo $__env->make('partials.profile_btns', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="side-menu">
      <h3 class="fl-l">Personal Details</h3>
      <?php if($member->misc->status == 'incomplete'): ?>
        <span class="fl-r profile-btns-menu">
          <img class="profile-btn-open" src="/images/dots.png">
        </span>
      <?php endif; ?>
      <div class="clr"></div>
      <hr>

      <p>Name: <?php echo e($member->f_name); ?> <?php echo e($member->surname); ?></p>
      <p>Contact: <?php echo e($member->cell_number); ?></p>
      <p>Email: <?php echo e($member->user->email); ?></p>

      <!--Member Status-->
      <?php switch($member->misc->status):
        case ('incomplete'): ?>
          <p>Status: <span class="txt-green">Registered</span></p>
          <p>Application: <span class="txt-red">Incomplete</span></p>
          <?php break; ?>
        <?php case ('review'): ?>
          <p>Status: <span class="txt-green">Registered</span></p>
          <p>Application: <span class="txt-yellow">Reviewing</span></p>
          <?php break; ?>
        <?php case ('approved'): ?>
          <p>Status: <span class="txt-green">Registered</span></p>
          <p>Application: <span class="txt-green">Approved</span></p>
          <?php break; ?>
        <?php case ('attention'): ?>
          <p>Status: <span class="txt-green">Registered</span></p>
          <p>Application: <span class="txt-yellow">Attention!</span></p>
          <?php break; ?>
        <?php case ('blocked'): ?>
          <p>Status: <span class="txt-red">Blocked</span></p>
          <p>Application: <span class="txt-red">Rejected!</span></p>
          <?php break; ?>
        <?php default: ?>
          <p>Status: <span class="txt-red">Not Defined</span></p>
      <?php endswitch; ?>
      <br>

      
      <?php if(count($docIDandType) > 0): ?>
        <p><b>Uploaded Documents:</b></p>
          <ol class="uploadedDocs">
            <?php $__currentLoopData = $docIDandType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="li-card">
                <span class="li-width"><?php echo e($document['type']); ?></span>
                <a href="/files/download/<?php echo e($document['id']); ?>"><i class="txt-green fas fa-download"></i></a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ol>
      <?php else: ?>
        <p><b>Uploaded Documents:</b></p>
        <ol class="uploadedDocs">
          <li>None</li>
        </ol>
      <?php endif; ?>

      <br>
      <br>
      <h3>Our Banking Details</h3>
      <hr>
      <p>
        Bank Name: FNB <br>
        Account Holder: Su Casa Property Investment Group PTY LTD <br>
        Account Number: 62830853489 <br>
        Branch Name: Bank City <br>
        Branch Code: 250805 <br>
        Reference: Please put your name and surname
      </p>
    </div>

    <div>
      
      <div class="profile-btns-desktop"> 
        <?php if($member->misc->status == 'incomplete'): ?> <?php echo $__env->make('partials.profile_btns', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/profile.blade.php ENDPATH**/ ?>