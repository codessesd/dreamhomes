<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      <span class="colour-sqr bg-primary"><i class="fas fa-users"></i></span>
      <div class="card-head-text">
        <h4 class="card-title ">Admins</h4>
        <p class="card-category">Admin list</p>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table members-table">
          <thead class="text-primary">
            <th>
            </th>
            <th>
              Name
            </th>
            <th>
              Email
            </th>
            <th>
              Contact
            </th>
            <th>
              Level
            </th>
            <th>
              Status
            </th>
            <th>
              Options
            </th>
            <th class="text-center">
              
            </th>
          </thead>
          <tbody>
            <?php $i = 0;/*members counter*/ ?>
            <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="text-primary">
                  <?php echo e(++$i); ?>.
                </td>
                <td class="table-f-name">
                  <?php echo e($admin->name); ?> <?php echo e($admin->surname); ?>

                  
                </td>
                <td>
                  <?php echo e($admin->user->email); ?>

                </td>
                <td>
                  <?php echo e($admin->contact); ?>

                </td>
                <td>
                  <?php echo e($admin->user->admin_level); ?>

                </td>
                <td>
                  <?php echo e($admin->status); ?>

                </td>
                <td class="options-td">
                  <div class="options d-flex justify-content-center">
                    <div class="options-icon" onclick="openAdminDetail(<?php echo e($admin['id']); ?>)" data-toggle="tooltip" data-placement="top" title="Edit Admin">
                      <i class="fas fa-pen"></i>
                    </div>

                    <div class="options-icon" onclick="location.href='/deleteAdmin/<?php echo e($admin->id); ?>'" data-toggle="tooltip" data-placement="top" title="Delete Admin">
                      <i class="fas fa-user-minus"></i>
                    </div>

                    

                  </div>
                </td>
              </tr>
              <?php echo $__env->make('dashboard.components.admin_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php echo $__env->make('dashboard.components.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <span class="btn bg-primary" onclick="openPopup()">Add New Admin</span>
        <div class="clr"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/admins.blade.php ENDPATH**/ ?>