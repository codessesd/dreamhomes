<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/application.blade.php ENDPATH**/ ?>