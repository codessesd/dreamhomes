<?php $__env->startSection('register','active'); ?>
<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <div class="register">
    <div class="form">
      <h1>Register</h1>

      <?php if(count($errors)  > 0): ?>
        <?php if(in_array('success',$errors->all())): ?>
          <div class="message bg-success">
          <h4>Success!</h4>
        <?php else: ?>
          <div class="message bg-error">
            <h4>Error</h4>
        <?php endif; ?>
          <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($error == 'success')||($error == 'resend')): ?>
             <li hidden><?php echo e($error); ?></li>
            <?php else: ?>
             <li><span></span><?php echo e($error); ?></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form class="register-form" action="/register" method="POST">
        <?php echo e(csrf_field()); ?>

        <?php if(in_array('resend',$errors->all())): ?>
          <button type="submit" class="btn" name="resend" value="resend">Resend Verification</button>
          <div class="clr"></div>
        <?php endif; ?>
        <label for="name">First Name</label>
        <input type="text" required name="f_name" value="<?php echo e(old('f_name')); ?>">
        <label for="surname">Surname</label>
        <input type="text" required name="surname" value="<?php echo e(old('surname')); ?>">
        <label for="contact-no">Contact Number</label>
        <input type="text" required name="contact_no" value="<?php echo e(old('contact_no')); ?>">
        <label for="email">Email</label>
        <input type="text" required name="email" value="<?php echo e(old('email')); ?>">
        <button type="submit" class="btn">Submit</button>
      </form>
    </div>
    <div class="side-pic">
      <img src="/images/house1.png">
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/register.blade.php ENDPATH**/ ?>