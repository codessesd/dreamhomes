<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php if(count($errors) > 0): ?>
    <?php echo $__env->make('partials.floatingMsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <div class="application areas-container">
    <h1>APPLICANTION STEP 4 OF 6</h1>
    <h3>Areas Of Choice</h3>

    <div class="grid-center-form">
      <div></div>
      <form class="areas-form applicant-details" id="main-form" action="/apply/step4" method="POST">
        <?php echo e(csrf_field()); ?>

          <div class="grid11 w100">
            <h4>Municipality</h4>
            <h4>Area</h4>
          </div>
          <div class="line spacer-btm"></div>
        <?php $i = 0; ?>
        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="grid11 w100 grid-list">
            <span><?php echo e(++$i); ?>. <?php echo e($area->municipality); ?></span>
            <span><?php echo e($area->area); ?></span>
            <span class="remove" onclick="location.href='/apply/step4/remove/<?php echo e($area->id); ?>'"><i class="fas fa-trash-alt"></i></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="grid11 w100">
            <div class="form-group">
              
              <select class="w100 padd5" id="municipality" name="municipality" required>
                <option value="Ekurhuleni">Ekurhuleni</option>
                <option value="Sedibeng/Vaal">Sedibeng/Vaal</option>
                <option value="City of Joburg">City of Joburg</option>
                <option value="Tshwane">Tshwane</option>
                <option value="West Rand">West Rand</option>
              </select>
            </div>
            <div class="form-group">
              <input id="area" oninput="enableAddArea()" type="text" name="area" required>
            </div>
            <div class="form-group btn-add">
              <button type="submit" ><i class="fas fa-plus-square"></i></button>
            </div>
          </div>
        <div class="clr"></div>
        
        
        <button type="button" id="btnNxt" onclick="submitArea()" class="spacer btn">Next</button>
        <button type="button" onclick="location.href='/apply/step3'" class="spacer btn">Back</button>
    </form>
    <div></div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/app_step4.blade.php ENDPATH**/ ?>