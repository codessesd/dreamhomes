<div class="popup-filter" id="popup-filter<?php echo e($admin->id); ?>">
<div class="popup">
  <div class="mem-top-nav bg-primary">
    <p class="pop-topBar">Edit Admin</p>
    <i class="fas fa-times" onclick="closeAdminDetail(<?php echo e($admin->id); ?>)"></i>
    
  </div>

  <div class="progressBox" id="progressBox<?php echo e($admin->id); ?>">
    <div class="img-div">
      <img id="loading<?php echo e($admin->id); ?>" src="/images/giphy3.gif" width="80px">
      <img id="warning<?php echo e($admin->id); ?>" src="/images/warning.svg" width="50px">
    </div>
    <div class="clr"></div>
    <span class="responseMsg"><b id="responseMsg<?php echo e($admin->id); ?>">This is a long response message  </b></span>
    <span class="okBtn" id="okBtn<?php echo e($admin->id); ?>" onclick="closeProgressBox()">OK</span>
  </div>
  <form id="admin-form<?php echo e($admin->id); ?>" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="grid-cover-50">
      <div class="dash-form-group">
        <label class="" for="name">Name </label>
        <input class="softborder" type="text" name="name" value="<?php echo e($admin->name); ?>">
      </div>

      <div class="dash-form-group">
        <label class="" for="surname">Surname </label>
        <input class="softborder" type="text" name="surname" value="<?php echo e($admin->surname); ?>">
      </div>

      <div class="dash-form-group">
        <label class="" for="id_number">ID Number </label>
        <input class="softborder" type="text" name="id_number" value="<?php echo e($admin->id_number); ?>">
      </div>

      <div class="dash-form-group">
        <label class="" for="contact">Contact </label>
        <input class="softborder" type="text" name="contact" value="<?php echo e($admin->contact); ?>">
      </div>

      <div class="dash-form-group">
        <label class="" for="email">Email </label>
        <input class="softborder" type="text" name="email" value="<?php echo e($admin->user->email); ?>" hidden>
        <input class="softborder" type="text" name="disabled-email" value="<?php echo e($admin->user->email); ?>" disabled>
      </div>

      <div class="dash-form-group">
        <label class="" for="password">Password </label>
        <input class="softborder" type="text" name="password" value="">
      </div>

      <div class="dash-form-group" style="display: none">
        
        <label for="admin_level">Admin Level <i class="fas fa-question-circle"></i></label>
        <select class="softborder" name="admin_level">
          <option value="9">Level 1</option>
          <option value="2">Level 2</option>
          <option value="3">Level 3</option>
          <option value="4">Level 4</option>
        </select>
      </div>
      <div class="clr"></div>
    </div>

    <div class="perms-cover">
      <fieldset>
        <legend>Write Permissions</legend>
        <button type="button" class="select-all" onclick="selectAll(<?php echo e($admin->id); ?>)">
          <input type="checkbox" id="btnSelectAll<?php echo e($admin->id); ?>">Select All
        </button>
        <div class="permissions">
          <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="entity-cover">
              <p class="entity-name"><?php echo e($table); ?></p>
              <div class="line"></div>
              <div class="perms-group">
                <?php $__currentLoopData = $writePermissions->where('entity',$table); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(in_array($permission->id,$admin->permissions->pluck('id')->all())): ?>
                    <input id="<?php echo e($permission->attribute); ?>" class="padded-check" type="checkbox" value="<?php echo e($permission->id); ?>" name="writePermissions[]" checked>
                  <?php else: ?>
                    <input id="<?php echo e($permission->attribute); ?>" class="padded-check" type="checkbox" value="<?php echo e($permission->id); ?>" name="writePermissions[]">
                  <?php endif; ?>
                  <label for="<?php echo e($permission->attribute); ?>">
                    <?php if(array_key_exists($permission->attribute,$readableNames)): ?>
                      <?php echo e($readableNames[$permission->attribute]); ?>

                    <?php else: ?>
                      <?php echo e($permission->attribute); ?>

                    <?php endif; ?>
                  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </fieldset>
    </div>
  </form>
  <div class="clr"></div>
  <span class="btn bg-primary" onclick="updateAdmin(<?php echo e($admin->id); ?>)"> Update </span>
  <div class="clr"></div>
</div>
</div>

<style type="text/css">

</style><?php /**PATH C:\Laravel\dreamHomes\resources\views/components/admin_details.blade.php ENDPATH**/ ?>