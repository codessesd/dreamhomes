<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php echo $__env->make('partials.fileUploader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php if(count($errors) > 0): ?>
    <?php echo $__env->make('partials.floatingMsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <div class="application areas-container">
    <h1>APPLICANTION STEP 5 OF 6</h1>
    <h3>Upload Files</h3>

    <div class="grid-center-form">
      <div></div>
      <div class="up-btns">
        <?php if($idOrPassport != null): ?>
          <div class="doc-li1">
            <p class="smCaps"><?php echo e($idOrPassport->original_name); ?></p>
            <span><i onclick="location.href='/files/delete/<?php echo e($idOrPassport->id); ?>'" class="icn fas fa-backspace"></i></span>
          </div>
        <?php else: ?> <p><i>Upload a certified copy of your ID or Passport</i></p> <?php endif; ?>
        <button type="button" class="btn4 w100" onclick="openDialog('ID OR Passport','<?php echo e($docTypes['id']); ?>')">Upload ID/Passport</button>
        <div class="clr"></div>
        <div class="line spacer-tb"></div>

        <?php if($proofop != null): ?>
          <div class="doc-li1">
            <p class="smCaps"><?php echo e($proofop->original_name); ?></p>
            <span><i onclick="location.href='/files/delete/<?php echo e($proofop->id); ?>'" class="icn fas fa-backspace"></i></span>
          </div>
        <?php else: ?> <p><i>Upload proof of payment. <a href="#">How to pay?</a></i></p> <?php endif; ?>
        <button type="button" class="btn4 w100" onclick="openDialog('Proof Of Payment','<?php echo e($docTypes['pr']); ?>')">Upload Proof of payment</button>
        <div class="clr"></div>
        <div class="line spacer-tb"></div>

        <?php if($supportDoc->count() > 0): ?>
          <?php $__currentLoopData = $supportDoc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="doc-li1">
              <p class="smCaps"><?php echo e($doc->original_name); ?></p>
              <span><i onclick="location.href='/files/delete/<?php echo e($doc->id); ?>'" class="icn fas fa-backspace"></i></span>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?> <p><i>Upload next of kin ID or beneficiary ID etc.</i></p> <?php endif; ?>
        <button type="button" class="btn4 w100" onclick="openDialog('More Supporting Documents','<?php echo e($docTypes['su']); ?>')">Upload More</button>
        <div class="clr"></div>
        <div class="line spacer-tb"></div>

        <div class="spacer-tb"></div>
        <div class="grid111">
          <button type="button" onclick="location.href='/profile'" id="btnNxt" class="btn">Upload Later</button>
          <button type="button" onclick="location.href='/apply/step4'" class="btn">Back</button>
          <button type="button" onclick="location.href='/apply/step6'"id="btnNxt" class="btn">Next</button>
        </div>
      </div>
      <div></div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/app_step5.blade.php ENDPATH**/ ?>