<?php $__env->startSection('admin-section'); ?>
  <h1>Welcome admin</h1>
  <div class="admin-container">
    <div class="left-menu">
      <ul>
        <li>Members</li>
        <li>Documents</li>
      </ul>
    </div>

  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin-master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/admin/dash.blade.php ENDPATH**/ ?>