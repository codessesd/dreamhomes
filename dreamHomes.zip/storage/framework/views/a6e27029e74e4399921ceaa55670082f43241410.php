<?php $__env->startSection('contact','active'); ?>
<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
<h1 class="center-h">Contact Us</h1>
  <div class="contact">
    <div class="contact-icon"><img  height="250px" src="/images/email.svg"></div>
    <div class="contact-text">
      <div class="contact-group">
        <p class="contact-label"><b>Address</b></p>
        <p class="contact-info">: 8968 Sonnyboy Street <br>Moleleki Ext2 <br>Katlehong</p>
        <div class="clr"></div>
      </div>
      <div class="contact-group">
        <p class="contact-label"><b>Email</b></p>
        <p class="contact-info">: <a href="mailto:heita@dhs.org.za">heita@dhs.org.za</a></p>
        <div class="clr"></div>
      </div>
      <div class="contact-group">
        <p class="contact-label"><b>Fax</b></p>
        <p class="contact-info">: 086 600 2848</p>
        <div class="clr"></div>
      </div>
      <div class="contact-group">
        <p class="contact-label"><b>Tel</b></p>
        <p class="contact-info">: 010 023 0800</p>
        <div class="clr"></div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/contact.blade.php ENDPATH**/ ?>