<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php if(count($errors) > 0): ?>
    <?php echo $__env->make('partials.floatingMsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <div class="application">
    <h1>APPLICANTION STEP 1 OF 6</h1>

    <form class="applicant-details" action="/apply/step1" method="POST">
      <?php echo e(csrf_field()); ?>

      <div class="form-group title">
        <label for="title">Title*</label>
        <input type="text" value="<?php echo e($member->title); ?>" name="member[title]">
      </div>
      <div class="form-group initials">
        <label for="initials">Initials*</label>
        <input type="text" value="<?php echo e($member->initials); ?>" name="member[initials]">
      </div>
      <div class="form-group first-name">
        <label for="first-name">First Name*</label>
        <input type="text" value="<?php echo e($member->f_name); ?>" name="member[f_name]" disabled>
      </div>
      <div class="form-group mid-name">
        <label for="mid-name">Middle Name</label>
        <input type="text" value="<?php echo e($member->middle_name); ?>" name="member[middle_name]">
      </div>
      <div class="form-group surname w50">
        <label for="surname">Surname*</label>
        <input type="text" value="<?php echo e($member->surname); ?>" name="member[surname]" disabled>
      </div>
      <div class="form-group id-passport w50">
        <label for="id-passport">ID/Passport*</label>
        <input type="text" value="<?php echo e($member->id_passport_no); ?>" name="member[id_passport_no]">
      </div>
      <div class="form-group tel-no w33">
        <label for="tel-no">Tel. No.</label>
        <input type="text" value="<?php echo e($member->tel_number); ?>" name="member[tel_number]">
      </div>
      <div class="form-group cell-no w33">
        <label for="cell-no">Cell Phone No.*</label>
        <input type="text" value="<?php echo e($member->cell_number); ?>" name="member[cell_number]">
      </div>
      <div class="form-group email w33">
        <label for="email">Email*</label>
        <input type="text" value="<?php echo e($member->user->email); ?>" name="user[email]" disabled>
      </div>
      <div class="clr"></div>
      <div class="marital-status">
        <label for="marital-status">Marital Status*</label>
        <select name="member[marital_status]" id="marital-status">
          <?php $ms = $member->marital_status; ?>
          <option value="Single" <?php if($ms=='Single'): ?>selected <?php endif; ?>>Single</option>
          <option value="Community of property" <?php if($ms=='Community of property'): ?>selected <?php endif; ?>>Community Of Property</option>
          <option value="Antenuptial contact" <?php if($ms=='Antenuptial contact'): ?>selected <?php endif; ?>>Antenuptual Contract</option>
          <option value="Widowed" <?php if($ms=='Widowed'): ?>selected <?php endif; ?>>Widowed</option>
          <option value="Divorced" <?php if($ms=='Divorced'): ?>selected <?php endif; ?>>Divorced</option>
          <option value="Civil union" <?php if($ms=='Civil union'): ?>selected <?php endif; ?>>Civil Union</option>
        </select>
      </div>
      <div class="insolvent">
        <label>Have you been declared insolvent?*</label>
        <select name="member[insolvency]">
          <?php $inslv = $member->insolvency; ?>
          <option value="No" <?php if($inslv=='No'): ?> selected <?php endif; ?>>No</option>
          <option value="Yes|Rehabilitated" <?php if($inslv=='Yes|Rehabilitated'): ?> selected <?php endif; ?>>Yes, I have been rehabilitated</option>
          <option value="Yes|NotRehabilitated" <?php if($inslv=='Yes|NotRehabilitated'): ?> selected <?php endif; ?>>Yes, I have NOT been rehabilitated</option>
        </select>
      </div>
      <div class="insolv2">
        <label>Are you under debt management or liquidation?*</label>
        <select name="member[liquidation]">
          <?php $liq = $member->liquidation; ?>
          <option value="No" <?php if($liq=='No'): ?> selected <?php endif; ?>>No</option>
          <option value="Yes" <?php if($liq=='Yes'): ?> selected <?php endif; ?>>Yes</option>
        </select>
      </div>
      <div class="physical-address address">
        <label>Physical Address*</label>
        <div class="grid-3">
          <input id="addr_line1" type="text" value="<?php echo e($home_address['addr_line1']); ?>" name="home_address[addr_line1]" placeholder="Address Line 1*">
          <input id="addr_line2" type="text" value="<?php echo e($home_address['addr_line2']); ?>" name="home_address[addr_line2]" placeholder="Address Line 2">
          <input id="suburb" type="text" value="<?php echo e($home_address['suburb']); ?>" name="home_address[suburb]" placeholder="Suburb*">
          <input id="city" type="text" value="<?php echo e($home_address['city']); ?>" name="home_address[city]" placeholder="City*">
          <input id="area_code" type="text" value="<?php echo e($home_address['area_code']); ?>" name="home_address[area_code]" placeholder="Area Code*">
        </div>
      </div>
      <div class="postal-address address">
        <label for="post_address[post_line1]">Postal Address*</label>
        <input type="checkbox" id="postCheckbox" onchange="populatePostAddress()"> <label for="postCheckbox" class="lbl-minor">Same of Physical</label>
        <div class="clr"></div>
        <textarea class="w33 post-address" rows="5" id="post-line1" name="post_address[post_line1]"><?php echo e($post_address['post_line1']); ?></textarea><br>
        <input class="w33" type="text" id="post-code" value="<?php echo e($post_address['post_code']); ?>" name="post_address[post_code]" placeholder="Postal Code*">
      </div>
      <div class="clr"></div>
      <button type="submit" class="btn spacer">Next</button>
      <button type="button" onclick="location.href='/profile'" id="btnNxt" class="spacer btn">Save for Later</button>
  </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/app_step1.blade.php ENDPATH**/ ?>