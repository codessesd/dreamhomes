<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
</head>
<body>

</body>
</html><?php /**PATH C:\Laravel\dreamHomes\resources\views/layouts/admin-master.blade.php ENDPATH**/ ?>