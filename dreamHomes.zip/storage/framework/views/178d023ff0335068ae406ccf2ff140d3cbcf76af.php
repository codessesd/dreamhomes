<?php
  $error = ["success","saved successfully"];
?>

<div class="msg-disabler" id="msg-disabler"></div>
  <div class="msg-dialog" id="msg-dialog">
    <div class="close"><img onclick="closeMsgDialog()" src="/images/close-red.svg" alt="close"></div>
    <?php if(in_array('success',$errors->all())): ?>
      <div class="message bg-success">
      <h4>Success!</h4>
    <?php elseif(in_array('warning',$errors->all())): ?>
      <div class="message bg-warning">
      <h4>Notice</h4>
    <?php else: ?> 
      <div class="message bg-error">
      <h4>Error</h4>
    <?php endif; ?>
      <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(($error == 'success')||($error == 'warning')): ?>
          <li hidden><?php echo e($error); ?></li>
        <?php else: ?>
          <li><span></span><?php echo e($error); ?></li>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div><?php /**PATH C:\Laravel\dreamHomes\resources\views/partials/floatingMsg.blade.php ENDPATH**/ ?>