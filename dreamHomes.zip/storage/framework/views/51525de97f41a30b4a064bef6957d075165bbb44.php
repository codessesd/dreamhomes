<div class="popup-filter" id="popup-filter">
<div class="popup">
  <div class="mem-top-nav bg-primary">
    <p class="pop-topBar">Add New Admin</p>
    <i class="fas fa-times" onclick="closePopup()"></i>
    
  </div>

  <div class="progressBox" id="progressBox">
    <div class="img-div">
      <img id="loading" src="/images/giphy3.gif" width="80px">
      <img id="warning" src="/images/warning.svg" width="50px">
    </div>
    <div class="clr"></div>
    <span class="responseMsg"><b id="responseMsg">This is a long response message  </b></span>
    <span class="okBtn" id="okBtn" onclick="closeProgressBox()">OK</span>
  </div>

  <form id="admin-form" action="addAdmin" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="grid-cover-50">
      <div class="dash-form-group">
        <label class=""  for="name">Name </label>
        <input class="softborder" type="text" name="name" value="">
      </div>

      <div class="dash-form-group">
        <label class="" for="surname">Surname </label>
        <input class="softborder" type="text" name="surname" value="">
      </div>

      <div class="dash-form-group">
        <label class="" for="id_number">ID Number </label>
        <input class="softborder" type="text" name="id_number" value="">
      </div>

      <div class="dash-form-group">
        <label class="" for="contact">Contact </label>
        <input class="softborder" type="text" name="contact" value="">
      </div>

      <div class="dash-form-group">
        <label class="" for="email">Email </label>
        <input class="softborder" type="text" name="email" value="">
      </div>

      <div class="dash-form-group">
        <label class="" for="password">Password </label>
        <input class="softborder" type="text" name="password" value="">
      </div>

      
      
      
    </div>

    <div class="perms-cover">
      <fieldset>
        <legend>Write Permissions</legend>
        
        <div class="permissions">
          <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="entity-cover">
              <p class="entity-name"><?php echo e($table); ?></p>
              <div class="line"></div>
              <div class="perms-group">
                <?php $__currentLoopData = $writePermissions->where('entity',$table); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <input id="<?php echo e($permission->attribute); ?>" class="padded-check" type="checkbox" value="<?php echo e($permission->id); ?>" name="writePermissions[]">
                  <label for="<?php echo e($permission->attribute); ?>">
                    <?php if(array_key_exists($permission->attribute,$readableNames)): ?>
                      <?php echo e($readableNames[$permission->attribute]); ?>

                    <?php else: ?>
                      <?php echo e($permission->attribute); ?>

                    <?php endif; ?>
                  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </fieldset>
    </div>
  </form>
  <div class="clr"></div>
  <span class="btn bg-primary" onclick="addAdmin()"> Add </span>
  <div class="clr"></div>
</div>
</div><?php /**PATH C:\Laravel\dreamHomes\resources\views/components/popup.blade.php ENDPATH**/ ?>