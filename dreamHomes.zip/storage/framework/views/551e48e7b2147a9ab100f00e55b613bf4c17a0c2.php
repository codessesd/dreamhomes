<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <?php if(count($errors) > 0): ?>
    <?php echo $__env->make('partials.floatingMsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>
  <div class="application">
    <h1>APPLICANTION STEP 3 OF 6</h1>
    <h3>Beneficiaries</h3>
    
    <div class="scrollable">
    <div class="mw550">
    <form class="applicant-details" id="benef-form" action="/apply/step3" method="POST">
      <?php echo e(csrf_field()); ?>

        <div class="grid1111 w100">
          <h4>Name</h4>
          <h4>Surname</h4>
          <h4>Relationship</h4>
          <h4>ID/Passport</h4>
        </div>
        <div class="line spacer-btm"></div>
      <?php $i = 0; ?>
      <?php $__currentLoopData = $beneficiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grid1111 w100 grid-list">
          <span><?php echo e(++$i); ?>. <?php echo e($beneficiary->name); ?></span>
          <span><?php echo e($beneficiary->surname); ?></span>
          <span><?php echo e($beneficiary->relationship); ?></span>
          <span><?php echo e($beneficiary->id_number); ?></span>
          <span class="remove" onclick="location.href='/apply/step3/remove/<?php echo e($beneficiary->id); ?>'"><i class="fas fa-trash-alt"></i></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="grid1111 w100">
          <div class="form-group">
            <input oninput="enableAddBen()" id="name" type="text" name="name" required>
          </div>
          <div class="form-group">
            <input oninput="enableAddBen()" id="surname" type="text" name="surname" required>
          </div>
          <div class="form-group">
            <select class="w100" name="relationship">
              <option value="Spouse">Spouse</option>
              <option value="Child">Child</option>
              <option value="Mother">Mother</option>
              <option value="Father">Father</option>
              <option value="Sister">Sister</option>
              <option value="Brother">Brother</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div class="form-group">
            <input oninput="enableAddBen()" id="id_number" type="text" name="id_number" required>
          </div>
          <div class="form-group btn-add">
            <button type="submit" ><i class="fas fa-plus-square"></i></button>
          </div>
        </div>
      <div class="clr"></div>
      <button type="button" id="btnNxt" class="btn spacer" onclick="submitBeneficiary()">Next</button>
      <button type="button" onclick="location.href='/apply/step2'" class="btn spacer">Back</button>
  </form>
  </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/app_step3.blade.php ENDPATH**/ ?>