<?php $__env->startSection('content'); ?>
<div class="application c80">
  <form class="applicant-details" action="/updateMember" method="POST">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="id" value="<?php echo e($member->id); ?>">

      
    <div class="form-divide">
      <h1>Member Details</h1>
      <div class="form-group title">
        <label for="title">Title*</label>
        <input type="text" value="<?php echo e($member->title); ?>" name="members[title]">
      </div>
      <div class="form-group initials">
        <label for="initials">Initials*</label>
        <input type="text" value="<?php echo e($member->initials); ?>" name="members[initials]">
      </div>
      <div class="form-group first-name">
        <label for="first-name">First Name*</label>
        <input type="text" value="<?php echo e($member->f_name); ?>" name="members[f_name]">
      </div>
      <div class="form-group mid-name">
        <label for="mid-name">Middle Name</label>
        <input type="text" value="<?php echo e($member->middle_name); ?>" name="members[middle_name]">
      </div>
      <div class="form-group surname w50">
        <label for="surname">Surname*</label>
        <input type="text" value="<?php echo e($member->surname); ?>" name="members[surname]">
      </div>
      <div class="form-group id-passport w50">
        <label for="id-passport">ID/Passport*</label>
        <input type="text" value="<?php echo e($member->id_passport_no); ?>" name="members[id_passport_no]">
      </div>
      <div class="form-group tel-no w33">
        <label for="tel-no">Tel. No.</label>
        <input type="text" value="<?php echo e($member->tel_number); ?>" name="members[tel_number]">
      </div>
      <div class="form-group cell-no w33">
        <label for="cell-no">Cell Phone No.*</label>
        <input type="text" value="<?php echo e($member->cell_number); ?>" name="members[cell_number]">
      </div>
      <div class="form-group email w33">
        <label for="email">Email*</label>
        <input type="text" value="<?php echo e($member->user->email); ?>" name="users[email]" disabled>
      </div>
      <div class="clr"></div>
      <div class=" form-group marital-status w33">
        <label for="marital-status">Marital Status*</label>
        <select name="members[marital_status]" id="marital-status">
          <?php $ms = $member->marital_status; ?>
          <option value="Single" <?php if($ms=='Single'): ?>selected <?php endif; ?>>Single</option>
          <option value="Community of property" <?php if($ms=='Community of property'): ?>selected <?php endif; ?>>Community Of Property</option>
          <option value="Antenuptial contact" <?php if($ms=='Antenuptial contact'): ?>selected <?php endif; ?>>Antenuptual Contract</option>
          <option value="Widowed" <?php if($ms=='Widowed'): ?>selected <?php endif; ?>>Widowed</option>
          <option value="Divorced" <?php if($ms=='Divorced'): ?>selected <?php endif; ?>>Divorced</option>
          <option value="Civil union" <?php if($ms=='Civil union'): ?>selected <?php endif; ?>>Civil Union</option>
        </select>
      </div>
      <div class="form-group insolvent w33">
        <label>Insolvent?*</label>
        <select name="members[insolvency]">
          <?php $inslv = $member->insolvency; ?>
          <option value="No" <?php if($inslv=='No'): ?> selected <?php endif; ?>>No</option>
          <option value="Yes|Rehabilitated" <?php if($inslv=='Yes|Rehabilitated'): ?> selected <?php endif; ?>>Yes, I have been rehabilitated</option>
          <option value="Yes|NotRehabilitated" <?php if($inslv=='Yes|NotRehabilitated'): ?> selected <?php endif; ?>>Yes, I have NOT been rehabilitated</option>
        </select>
      </div>
      <div class="form-group insolv2 w33">
        <label>Debt management or liquidation?*</label>
        <select name="members[liquidation]">
          <?php $liq = $member->liquidation; ?>
          <option value="No" <?php if($liq=='No'): ?> selected <?php endif; ?>>No</option>
          <option value="Yes" <?php if($liq=='Yes'): ?> selected <?php endif; ?>>Yes</option>
        </select>
      </div>
      <div class="form-group physical-address w100">
        <br>
        <label>Physical Address*</label>
        <div class="grid-3">
          <input id="addr_line1" type="text" value="<?php echo e($member->home_address['addr_line1']); ?>" name="home_addresses[addr_line1]" placeholder="Address Line 1*">
          <input id="addr_line2" type="text" value="<?php echo e($member->home_address['addr_line2']); ?>" name="home_addresses[addr_line2]" placeholder="Address Line 2">
          <input id="suburb" type="text" value="<?php echo e($member->home_address['suburb']); ?>" name="home_addresses[suburb]" placeholder="Suburb*">
          <input id="city" type="text" value="<?php echo e($member->home_address['city']); ?>" name="home_addresses[city]" placeholder="City*">
          <input id="area_code" type="text" value="<?php echo e($member->home_address['area_code']); ?>" name="home_addresses[area_code]" placeholder="Area Code*">
        </div>
      </div>
      <div class="form-group postal-address w50">
        <label for="post_address[post_line1]">Postal Address*</label>
        
        <div class="clr"></div>
        <textarea class="w100 post-address" rows="5" id="post-line1" name="post_addresses[post_line1]"><?php echo e($member->post_address['post_line1']); ?></textarea><br>
        <input class="w33" type="text" id="post-code" value="<?php echo e($member->post_address['post_code']); ?>" name="post_addresses[post_code]" placeholder="Postal Code*">
      </div>
      <div class="clr"></div>
    </div>

    
    <div class="form-divide">
      <h1>Next of Kin</h1>

      <div class="grid1122">
        <div class="form-group">
          <label for="title">Title*</label>
          <input type="text" name="next_of_kin[title]" value="<?php echo e($member->next_of_kin['title']); ?>">
        </div>
        <div class="form-group">
          <label for="initials">Initials*</label>
          <input type="text" name="next_of_kin[initials]" value="<?php echo e($member->next_of_kin['initials']); ?>">
        </div>
        <div class="form-group">
          <label for="first-name">First Name*</label>
          <input type="text" name="next_of_kin[name]" value="<?php echo e($member->next_of_kin['name']); ?>">
        </div>
        <div class="form-group">
          <label for="surname">Surname*</label>
          <input type="text" name="next_of_kin[surname]" value="<?php echo e($member->next_of_kin['surname']); ?>">
        </div>
      </div>
      <div class="form-group w33">
        <label for="relationship">Relationship*</label>
        <select class="w100" name="next_of_kin[relationship]">
          <option value="Spouse" <?php if($member->next_of_kin['relationship'] == 'Spouse'): ?>  selected <?php endif; ?>>Spouse</option>
          <option value="Child" <?php if($member->next_of_kin['relationship'] == 'Child'): ?> selected <?php endif; ?>>Child</option>
          <option value="Mother" <?php if($member->next_of_kin['relationship'] == 'Mother'): ?> selected <?php endif; ?>>Mother</option>
          <option value="Father" <?php if($member->next_of_kin['relationship'] == 'Father'): ?> selected <?php endif; ?>>Father</option>
          <option value="Sister" <?php if($member->next_of_kin['relationship'] == 'Sister'): ?> selected <?php endif; ?>>Sister</option>
          <option value="Brother" <?php if($member->next_of_kin['relationship'] == 'Brother'): ?> selected <?php endif; ?>>Brother</option>
          <option value="Other" <?php if($member->next_of_kin['relationship'] == 'Other'): ?> selected <?php endif; ?>>Other</option>
        </select>
      </div>
      <div class="form-group cell-no w33">
        <label for="contact_no">Cell Phone No.</label>
        <input type="text" name="next_of_kin[contact_no]" value="<?php echo e($member->next_of_kin['contact_no']); ?>">
      </div>
      <div class="form-group email w33">
        <label for="email">Email</label>
        <input type="text" name="next_of_kin[email]" value="<?php echo e($member->next_of_kin['email']); ?>">
      </div>
      <div class="form-group physical-address w50">
        <label>Physical Address*</label>
        <div class="">
          <textarea class="w100" rows="2" name="next_of_kin[address_line_1]"><?php echo e($member->next_of_kin['address_line_1']); ?></textarea><br>
          <input type="text" class="w33" name="next_of_kin[suburb]" placeholder="Surbub" value="<?php echo e($member->next_of_kin['suburb']); ?>">
          <input type="text" class="w33" name="next_of_kin[city]" placeholder="City" value="<?php echo e($member->next_of_kin['city']); ?>">
          <input type="text" class="w33" name="next_of_kin[area_code]" placeholder="Area Code" value="<?php echo e($member->next_of_kin['area_code']); ?>">
        </div>
      </div>
      <div class="form-group postal-address w50">
        <label>Postal Address</label>
        <textarea class="w100" rows="2" name="next_of_kin[postal_address]"><?php echo e($member->next_of_kin['postal_address']); ?></textarea><br>
        <input class="w33" type="text" class="" name="next_of_kin[postal_code]" placeholder="Postal Code" value="<?php echo e($member->next_of_kin['postal_code']); ?>">
      </div>
      <div class="clr"></div>
    </div>

    
    <div class="form-divide">
      <h1>Beneficiaries</h1>

      <div class="grid1111 w100">
          <h4>Name</h4>
          <h4>Surname</h4>
          <h4>Relationship</h4>
          <h4>ID/Passport</h4>
        </div>
        <div class="line spacer-btm"></div>
      <?php $i = 0; ?>
      <?php $__currentLoopData = $member->beneficiaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beneficiary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="grid1111 w100 grid-list">
          <span><?php echo e(++$i); ?>. <?php echo e($beneficiary->name); ?></span>
          <span><?php echo e($beneficiary->surname); ?></span>
          <span><?php echo e($beneficiary->relationship); ?></span>
          <span><?php echo e($beneficiary->id_number); ?></span>
          <span class="remove" onclick="location.href='/apply/step3/remove/<?php echo e($beneficiary->id); ?>'"><i class="fas fa-trash-alt"></i></span>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="grid1111 w100">
          <div class="form-group">
            <input oninput="enableAddBen()" id="name" type="text" name="name">
          </div>
          <div class="form-group">
            <input oninput="enableAddBen()" id="surname" type="text" name="surname">
          </div>
          <div class="form-group">
            <select class="w100" name="relationship">
              <option value="Spouse">Spouse</option>
              <option value="Child">Child</option>
              <option value="Mother">Mother</option>
              <option value="Father">Father</option>
              <option value="Sister">Sister</option>
              <option value="Brother">Brother</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div class="form-group">
            <input oninput="enableAddBen()" id="id_number" type="text" name="id_number">
          </div>
          <div class="form-group btn-add">
            <button type="submit" ><i class="fas fa-plus-square"></i></button>
          </div>
        </div>
    </div>

    
    <div class="form-divide">
      <h1>Areas of Choice</h1>

      <div class="grid11 w100">
            <h4>Municipality</h4>
            <h4>Area</h4>
          </div>
          <div class="line spacer-btm"></div>
        <?php $i = 0; ?>
        <?php $__currentLoopData = $member->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="grid11 w100 grid-list">
            <span><?php echo e(++$i); ?>. <?php echo e($area->municipality); ?></span>
            <span><?php echo e($area->area); ?></span>
            <span class="remove" onclick="location.href='/apply/step4/remove/<?php echo e($area->id); ?>'"><i class="fas fa-trash-alt"></i></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="grid11 w100">
            <div class="form-group">
              <select class="w100 padd5" id="municipality" name="municipality">
                <option value="Ekurhuleni">Ekurhuleni</option>
                <option value="Sedibeng/Vaal">Sedibeng/Vaal</option>
                <option value="City of Joburg">City of Joburg</option>
                <option value="Tshwane">Tshwane</option>
                <option value="West Rand">West Rand</option>
              </select>
            </div>
            <div class="form-group">
              <input id="area" oninput="enableAddArea()" type="text" name="area">
            </div>
            <div class="form-group btn-add">
              <button type="submit" ><i class="fas fa-plus-square"></i></button>
            </div>
          </div>
      </div>

      <button type="submit">Update Member</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/member.blade.php ENDPATH**/ ?>