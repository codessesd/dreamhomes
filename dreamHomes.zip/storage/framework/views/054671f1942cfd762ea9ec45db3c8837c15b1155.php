<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <h3>Hello <?php echo e($name); ?></h3>

  <p><?php echo e($emailMessage); ?></p>
  <p><a href="<?php echo e($link); ?>"><?php echo e($link); ?></a></p>
</body>
</html><?php /**PATH C:\Laravel\dreamHomes\resources\views/accounts_mail.blade.php ENDPATH**/ ?>