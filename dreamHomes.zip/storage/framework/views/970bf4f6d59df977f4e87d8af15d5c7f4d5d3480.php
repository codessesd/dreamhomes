<?php $__env->startSection('content'); ?>
  <div class="card">
    <div class="card-header">
      <span class="colour-sqr bg-primary"><i class="fas fa-users"></i></span>
      <div class="card-head-text">
        <h4 class="card-title ">Members</h4>
        <p class="card-category">DHS member list</p>
      </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table members-table">
          <thead class="text-primary">
            <th>
            </th>
            <th>
              Name
            </th>
            <th>
              Membership
            </th>
            <th>
              ID/Passport
            </th>
            <th>
              Contact
            </th>
            <th>
              Pos
            </th>
            <th class="text-center">
              
            </th>
          </thead>
          <tbody>
            <?php $i = 0;/*members counter*/ ?>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="text-primary">
                  <?php echo $__env->make('dashboard.components.office_use', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php echo e(++$i); ?>.
                </td>
                <td class="table-f-name">
                  <a class="nameLink" href="/member/<?php echo e($member->id); ?>"><?php echo e($member->f_name); ?> <?php echo e($member->surname); ?></a>
                </td>
                <td>
                  <?php echo e($member->misc->membership_no); ?>

                </td>
                <td>
                  <?php echo e($member->id_passport_no); ?>

                </td>
                <td>
                  <?php echo e($member->cell_number); ?>

                </td>
                <td>
                  <?php echo e($member->position); ?>

                </td>
                <td class="options-td">
                  <div class="options d-flex justify-content-center">
                    <div class="options-icon" onclick="toggleOfficePopup(<?php echo e($member['id']); ?>)" data-toggle="tooltip" data-placement="top" title="Office Use">
                      <i class="fas fa-edit"></i>
                    </div>
                    <a class="options-icon" href="/member/<?php echo e($member->id); ?>" data-toggle="tooltip" data-placement="top" title="Open Member">
                      <i class="fas fa-eye"></i>
                    </a>
                    <div class="options-icon" onclick="toggleDocPopup(<?php echo e($member['id']); ?>)" data-toggle="tooltip" data-placement="top" title="Documents">
                      <i class="far fa-file-alt"></i>
                      <?php if($member->document->isNotEmpty()): ?>
                        <div class="doc-popup" id="popup<?php echo e($member['id']); ?>">
                          <span class="doc-li">Close</span>
                          <?php echo $__env->make('dashboard.components.documents_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                      <?php else: ?>
                        <div class="doc-popup" id="popup<?php echo e($member['id']); ?>">
                          <span class="doc-li">No Uploads</span>
                          <span class="doc-li"><i class="fas fa-times"></i> Close</span>
                        </div>
                      <?php endif; ?>
                    </div>

                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/dashboard/members.blade.php ENDPATH**/ ?>