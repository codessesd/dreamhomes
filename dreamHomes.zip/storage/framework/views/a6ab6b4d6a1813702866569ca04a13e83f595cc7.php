<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <div class="register">
    <div class="form">
      <h1>Set Password</h1>

      <?php if(count($errors)  > 0): ?>
        <?php if(in_array('success',$errors->all())): ?>
          <div class="message bg-success">
          <h4>Success!</h4>
        <?php else: ?>
          <div class="message bg-error">
            <h4>Error</h4>
        <?php endif; ?>
          <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($error == 'success'): ?>
             <li hidden><?php echo e($error); ?></li>
            <?php else: ?>
             <li><span></span><?php echo e($error); ?></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form class="password-form" action="/<?php echo e($formAction); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="token" value="<?php echo e($token); ?>">
        <input type="hidden" name="email_token" value="<?php echo e($email_token); ?>">
        <label for="password">Password</label>
        <input type="password" name="password" required>
        <label for="password_confirmation">Confirm Password</label>
        <input type="password" name="password_confirmation" required>
        <button type="submit" class="btn">Submit</button>
      </form>

    </div>
    <div class="side-pic">
      <img src="/images/house1.png">
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/setPassword.blade.php ENDPATH**/ ?>