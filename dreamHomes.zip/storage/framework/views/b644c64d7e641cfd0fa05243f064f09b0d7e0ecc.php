<div class="banner-container">
  <div class="banner-line"></div>
</div><?php /**PATH C:\Laravel\dreamHomes\resources\views/partials/banner2.blade.php ENDPATH**/ ?>