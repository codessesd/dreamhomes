<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <div class="register">
    <div class="form">
      <h1><?php echo e($erSMessage['bigTitle']); ?></h1>
        <div class="message <?php echo e($erSMessage['bgColor']); ?>">
          <h4><?php echo e($erSMessage['smallTitle']); ?></h4>
          <ul>
            <?php $__currentLoopData = $erSMessage['theMessages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><span></span><?php echo e($msg); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
    </div>
      <div class="side-pic">
        <img src="/images/house1.png">
      </div>
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/messages.blade.php ENDPATH**/ ?>