<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('wide-section1'); ?>
 <h1>Welcome to admin</h1>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/admin.blade.php ENDPATH**/ ?>