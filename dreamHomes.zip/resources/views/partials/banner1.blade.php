<div class="banner-container">
  <div class="banner-line"></div>
  <div class="banner-pic">
    <div class="filter"></div>
    <img src="/images/banner2.jpg">
  </div>
</div>