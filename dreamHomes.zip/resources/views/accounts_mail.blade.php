<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <h3>Hello {{$name}}</h3>

  <p>{{$emailMessage}}</p>
  <p><a href="{{$link}}">{{$link}}</a></p>
</body>
</html>