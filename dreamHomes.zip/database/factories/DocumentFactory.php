<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\document;
use Faker\Generator as Faker;

$factory->define(document::class, function (Faker $faker) {
    return [
        //
    ];
});
