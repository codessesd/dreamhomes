<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Section9Controller extends Controller
{
    //
}
