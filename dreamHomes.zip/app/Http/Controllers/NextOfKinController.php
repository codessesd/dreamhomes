<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NextOfKinController extends Controller
{
    //
}
