<div class="banner-container">
  <div class="banner-line"></div>
</div>