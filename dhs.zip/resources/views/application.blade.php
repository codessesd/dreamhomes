@extends('layouts.master')
@section('banner')
  @include('partials.banner2')
@endsection