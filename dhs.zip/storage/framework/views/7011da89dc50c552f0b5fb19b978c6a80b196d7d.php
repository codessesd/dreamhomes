<!DOCTYPE html>
<html>
<head>
  <title>Dream Homes Stokvel</title>
  <link rel="stylesheet" type="text/css" href="/css/styles.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat|Raleway&display=swap" rel="stylesheet">
</head>
<body>
  <div class="website">
    <div class="info-bar"></div>

    <div class="header-container">
      <div class="logo">
        <a href="/"><img src="/images/logo.png" alt="dream homes stokvel"></a>
      </div>
      <div class="menu-container main-menu">
          <ul>
            <li class="<?php echo $__env->yieldContent('home'); ?>"><a href="/">Home</a></li>
            <li class="<?php echo $__env->yieldContent('about'); ?>"><a href="/about">About</a></li>
            <li class="<?php echo $__env->yieldContent('contact'); ?>"><a href="/contact">Contact</a></li>
            <?php if(auth()->check()): ?>
              <li class="<?php echo $__env->yieldContent('profile'); ?>"><a href="/profile">Profile</a></li>
            <?php else: ?>
              <li class="<?php echo $__env->yieldContent('register'); ?>"><a href="/register">Register</a></li> 
            <?php endif; ?>
          </ul>
        <?php if(auth()->check()): ?>
          <span class="btn login"><a href="/logout">Logout</a></span>
        <?php else: ?>
          <span class="btn login"><a href="/login">Login</a></span>
        <?php endif; ?>
      </div>
    </div>

    <?php echo $__env->yieldContent('banner'); ?>

    <div class="section">
      <?php echo $__env->yieldContent('section'); ?>
    </div>

    <div class="wide-section1">
      <?php echo $__env->yieldContent('wide-section1'); ?>
      <div class="clr"></div>
    </div>

    <div class="footer">
      <div class="footer-inner">
        <div class="ftr-left"></div>
        <div class="ftr-mid">&copy;2020 Copyright DreamHomes Stokvel</div>
        <div class="ftr-right"></div>
      </div>
    </div>
  </div>
</body>
</html><?php /**PATH C:\Laravel\dreamHomes\resources\views/layouts/master.blade.php ENDPATH**/ ?>