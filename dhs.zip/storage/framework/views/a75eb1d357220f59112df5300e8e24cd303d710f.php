<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <div class="register">
    <div class="form">
      <h1>Login</h1>

      <?php if(count($errors)  > 0): ?>
        <div class="message bg-error">
          <h4>Error</h4>
          <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><span></span><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form class="register-form" action="/login" method="POST">
        <?php echo e(csrf_field()); ?>

        <label for="email">Email</label>
        <input type="text" required name="email" value="<?php echo e(old('email')); ?>">
        <label for="password">Password</label>
        <input type="password" required name="password">
        <button type="submit" class="btn">Login</button>
      </form>
    </div>
    <div class="side-pic">
      <img src="/images/house1.png">
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/login.blade.php ENDPATH**/ ?>