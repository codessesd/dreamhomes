<?php $__env->startSection('banner'); ?>
  <?php echo $__env->make('partials.banner2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('section'); ?>
  <div class="register">
    <div class="form">
      <?php
        //A different message is displayed depending on the $message variable
        if ($message == "verifyLinkExpired"){
          $msgHeading1 = "invalid Link";
          $msgHeading2 = "Error";
          $msgColour = "bg-error";
          $msgContent = ["This link is invalid or may have expired. Please check the link or try to register again."];
        }
        elseif ($message == "passwordSuccess"){
          $msgHeading1 = "Success";
          $msgHeading2 = "";
          $msgColour = "bg-success";
          $msgContent = ["Password set Successfully","You can now Login"];
        }elseif ($message == "loggedOut"){
          $msgHeading1 = "Logged Out";
          $msgHeading2 = "";
          $msgColour = "bg-success";
          $msgContent = ["You have successfully logged out!"];
        }
        else //default Error Message
          $msgContent = ["Error","bg-error","Opps...","Something went wrong"]
      ?>

      <h1><?php echo e($msgHeading1); ?></h1>
        <div class="message <?php echo e($msgColour); ?>">
          <h4><?php echo e($msgHeading2); ?></h4>
          <ul>
            <?php $__currentLoopData = $msgContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><span></span><?php echo e($msg); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
    </div>
      <div class="side-pic">
        <img src="/images/house1.png">
      </div>
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\dreamHomes\resources\views/messages.blade.php ENDPATH**/ ?>